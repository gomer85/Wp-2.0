export class sport {
    id: number;
    name: string;
}
