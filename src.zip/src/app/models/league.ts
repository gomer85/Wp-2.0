export class League {
  id: number;
  name: string;
  sportId: number;
}
