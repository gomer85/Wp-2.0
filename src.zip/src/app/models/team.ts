export class Team {
    id: number;
    name: string;
    sportId: number;
    seasonId: number;
}
