export class Arena {
  name: string;
}
