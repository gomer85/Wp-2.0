export class Sport {
    id: number;
    name: string;
}
