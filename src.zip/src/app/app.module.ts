import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms"
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import { MainNavComponent } from './main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { GetAllSportsComponent } from './components/get-all-sports/get-all-sports.component';
import { AddSportComponent } from './components/add-sport/add-sport.component';
import { AddLeagueComponent } from './components/add-league/add-league.component';
import { AddArenaComponent } from './components/add-arena/add-arena.component';
import { AddTeamComponent } from './components/add-team/add-team.component';
import { AddLeagueBySportidComponent } from './components/add-league-by-sportid/add-league-by-sportid.component';
import { GetLeagueByIdComponent } from './components/get-league-byid/get-league-byid.component';
import { GetLeagueBysportidComponent } from './components/get-league-bysportid/get-league-bysportid.component';
import { GetTeamByidComponent } from './components/get-team-byid/get-team-byid.component';
import { GetTeamByseasonComponent } from './components/get-team-byseason/get-team-byseason.component';
import { GetTeamBysportComponent } from './components/get-team-bysport/get-team-bysport.component';


@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    GetAllSportsComponent,
    AddSportComponent,
    AddLeagueComponent,
    AddArenaComponent,
    AddTeamComponent,
    AddLeagueBySportidComponent,
    GetLeagueByIdComponent,
    GetLeagueBysportidComponent,
    GetTeamByidComponent,
    GetTeamByseasonComponent,
    GetTeamBysportComponent,
  ],
  imports: [
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    MatSliderModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    RouterModule.forRoot([
      { path: 'GetAllSports', component: GetAllSportsComponent },
      { path: 'AddSport', component: AddSportComponent},
      { path: 'AddLeague', component: AddLeagueComponent},
      { path: 'AddArena', component: AddArenaComponent},
      { path: 'AddTeam', component: AddTeamComponent},
      { path: 'GetLeagueById', component: GetLeagueByIdComponent},
      { path: 'GetLeaguesBySportId', component: GetLeagueBysportidComponent},
      { path: 'GetTeamById', component: GetTeamByidComponent},
      { path: 'GetTeamBySeason', component: GetTeamByseasonComponent},
      { path: 'GetTeamBySport', component: GetTeamBysportComponent},

    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
