import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { TeamService } from '../../services/teamService';
import { Team } from '../../models/team';
@Component({
  selector: 'app-get-team-bysport',
  templateUrl: './get-team-bysport.component.html',
  styleUrls: ['./get-team-bysport.component.css']
})
export class GetTeamBysportComponent implements OnInit {

  getTeamsBySportForm = new FormGroup({
      sportId: new FormControl(''),
    });

    data: string[];
    labelId: string

    constructor(private teamService: TeamService) { }

    ngOnInit() {
    }

    changeLabel(labelId) {
      this.labelId = labelId;
    }

    makeReadable(data) {
      var text = "";
      for (let i = 0; i < data.length; i++) {
        text = text + "ID = " + data[i].id;
        text = text + " name = " + data[i].name + "<br>";
      }

      return text
    }
    onSubmit(): void {
      var sportId = this.getTeamsBySportForm.controls.sportId.value;

      this.teamService.getTeamsBySport(sportId).subscribe(data => {
        console.log(data);
        var newData = this.makeReadable(data);
        document.getElementById(this.labelId).innerHTML = newData;
      });
    }


  }
