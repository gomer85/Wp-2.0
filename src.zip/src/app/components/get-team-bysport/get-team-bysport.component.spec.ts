import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTeamBysportComponent } from './get-team-bysport.component';

describe('GetTeamBysportComponent', () => {
  let component: GetTeamBysportComponent;
  let fixture: ComponentFixture<GetTeamBysportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTeamBysportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTeamBysportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
