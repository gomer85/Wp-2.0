import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTeamByidComponent } from './get-team-byid.component';

describe('GetTeamByidComponent', () => {
  let component: GetTeamByidComponent;
  let fixture: ComponentFixture<GetTeamByidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTeamByidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTeamByidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
