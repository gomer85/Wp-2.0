import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLeagueBySportidComponent } from './add-league-by-sportid.component';

describe('AddLeagueBySportidComponent', () => {
  let component: AddLeagueBySportidComponent;
  let fixture: ComponentFixture<AddLeagueBySportidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLeagueBySportidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLeagueBySportidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
