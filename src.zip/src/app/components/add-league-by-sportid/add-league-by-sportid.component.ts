import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-league-by-sportid',
  templateUrl: './add-league-by-sportid.component.html',
  styleUrls: ['./add-league-by-sportid.component.css']
})
export class AddLeagueBySportidComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
