import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTeamByseasonComponent } from './get-team-byseason.component';

describe('GetTeamByseasonComponent', () => {
  let component: GetTeamByseasonComponent;
  let fixture: ComponentFixture<GetTeamByseasonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTeamByseasonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTeamByseasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
