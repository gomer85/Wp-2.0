import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddArenaComponent } from './add-arena.component';

describe('AddArenaComponent', () => {
  let component: AddArenaComponent;
  let fixture: ComponentFixture<AddArenaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddArenaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddArenaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
