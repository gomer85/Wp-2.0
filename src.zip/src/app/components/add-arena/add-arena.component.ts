import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { ArenaService } from '../../services/arenaService';
import { Arena } from '../../models/arena';

@Component({
  selector: 'app-add-arena',
  templateUrl: './add-arena.component.html',
  styleUrls: ['./add-arena.component.css']
})
export class AddArenaComponent implements OnInit {

  constructor(private route: ActivatedRoute, private arenaService: ArenaService) { }

  addArenaForm = new FormGroup({
    name: new FormControl(''),
  });

  ngOnInit() {
  }
  onSubmit() {
    var arena = new Arena();
    arena.name = this.addArenaForm.controls.name.value;

    this.arenaService.addArena(arena);
    this.addArenaForm.reset();
  }
}
