import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetLeagueByidComponent } from './get-league-byid.component';

describe('GetLeagueByidComponent', () => {
  let component: GetLeagueByidComponent;
  let fixture: ComponentFixture<GetLeagueByidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetLeagueByidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetLeagueByidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
